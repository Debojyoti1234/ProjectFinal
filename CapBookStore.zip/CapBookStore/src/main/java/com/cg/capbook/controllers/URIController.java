package com.cg.capbook.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.capbook.beans.CapBookUser;

@Controller
public class URIController 
{
	public CapBookUser user;
	
   @RequestMapping(value= {"/","index"})
   public String getIndexPage()
   {
	   return "index";
   }
   
   @RequestMapping("/registration")
   public String getRegistrationPage()
   {
	   return "registrationPage";
   }
   
   @RequestMapping("/login")
   public String getLogin()
   {
	   return "login";
   }
   @RequestMapping("/start")
   public String getStart()
   {
	   return "start";
   }
   
   @RequestMapping("/forgetpass")
   public String getforgetpass()
   {
	   return "forgetPasswordPage";
   }
   
   @RequestMapping("/setPassword")
   public String getsetPassword()
   {
	   return "setNewPasswordPage";
   }
  
   
   @ModelAttribute
   public CapBookUser getCapBookUser() {
	   user = new CapBookUser();
	   return user;
   }
 
  
 
}
